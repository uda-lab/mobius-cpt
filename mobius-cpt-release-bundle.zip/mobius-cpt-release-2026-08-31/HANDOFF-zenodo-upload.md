# Handoff — Zenodo deposit of the mobius-cpt public note (v0.1.0)

## Task
Create a **draft** Zenodo record for the note using the files in this bundle directory, fill every metadata field from `zenodo-metadata.json`, and stop at the draft stage. **Never press "Publish"** — publishing mints a DOI and is irreversible; the owner presses it after reviewing the draft.

## Files to upload (all in this directory; upload exactly these, nothing else)
1. `mobius-cpt-note.pdf` — the note (23 pages); mark it as the default preview if the UI asks.
2. `source-snapshot-fad7a6224ae608a56be5f212ece8837d209199bd.tar.gz` — repository tree at the audited revision.
3. `mobius-cpt-note.tex`, `mobius-cpt-note.bib`, `CITATION.cff` — source and citation metadata.
Do not upload `zenodo-metadata.json`, `MANIFEST.md`, `README.md`, this file, or `zenodo-description.txt`.

## Metadata (source of truth: `zenodo-metadata.json`; plain-text description in `zenodo-description.txt`)
- Resource type: **Publication → Preprint**.
- Title: `Formalising the PCT Theorem for Möbius-Covariant Wightman Conformal Field Theories on the Circle`
- Publication date: `2026-09-01`.
- Creators: one — family name `Uda`, given name `Tomoki`, affiliation `Faculty of Science and Technology, Nanzan University`, ORCID `0000-0002-6073-1572`. Role: creator/author only. **No other person is added anywhere** (no contributors).
- Description: paste the three paragraphs of `zenodo-description.txt` as plain text (the JSON holds an HTML version; the editor renders raw tags if you paste that).
- License: **Apache License 2.0** (`apache2.0`). Access right: **Open**. Language: **Japanese**.
- Version: `0.1.0`.
- Keywords (one per entry, in this order): PCT theorem; conformal field theory; Wightman axioms; Möbius covariance; non-unitary vertex algebras; analytic continuation; formal verification; interactive theorem proving; Lean 4; mathlib.
- Related works:
  - `https://github.com/uda-lab/mobius-cpt/tree/fad7a6224ae608a56be5f212ece8837d209199bd` — relation *Is supplement to*, resource type *Software*.
  - `https://github.com/uda-lab/mobius-cpt` — *Is supplement to*, *Software*.
  - `arXiv:2506.10625` — *References*, *Publication / Preprint* (scheme arXiv).
  - `arXiv:2409.08454` — *References*, *Publication / Preprint* (scheme arXiv).
- Additional notes (if the form has the field): the text of `"notes"` in `zenodo-metadata.json`.
- Communities, funding, subjects, dates, references: leave empty. Do not enable the GitHub integration; no GitHub release exists.

## Procedure
1. Open https://zenodo.org/uploads/new (already logged in). Zenodo's current form (InvenioRDM) is a single page.
2. Files: use the **"Upload files"** button, not drag-and-drop. In the native file dialog type the full path of the bundle directory (macOS: ⌘⇧G then paste the path; Windows/GTK: paste into the file-name box). Select the five files listed above; wait until every row shows the checkmark and the total size ≈ 0.9 MB.
3. Fill the fields in the order they appear; for creators use "Add creator" → Person, then fill the ORCID and affiliation fields in the same dialog; for related works use "Add" and set relation + resource type per entry.
4. If the form offers **"Get a DOI now"**/"Reserve DOI", reserve it and copy the DOI into your final report — the owner will add it to `CITATION.cff` afterwards. If it is not offered before publish, skip.
5. Click **Save draft**. Take a full-page screenshot of the saved draft and check every field against this file. Report field-by-field and list anything you could not set.
6. Stop. The owner reviews and publishes.

## Known traps
- `Möbius`: keep the umlaut in the title/keywords.
- The abstract mentions `{propext, Classical.choice, Quot.sound}` and revision `fad7a6224ae608a56be5f212ece8837d209199bd`: copy exactly, no reflow.
- The bundle README's "Rebuilding the PDF" section is for readers of the deposit, not a step here.
- If Zenodo rejects Apache-2.0 for a publication, do not pick another license: report and stop.
