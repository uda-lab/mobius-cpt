# Zenodo deposit bundle — mobius-cpt public note v0.1.0

Upload-ready. The deposit itself needs the owner's Zenodo account and is not attempted here;
no Zenodo credential or automation is added to the repository.

Refreshed on 2026-09-01 against the note as revised under Issue #74 (final publication audit),
superseding the Issue #67 bundle.

## Contents

| File | Role |
|---|---|
| `mobius-cpt-note.pdf` | The deposit artefact. 23 pages, built from the sources beside it with the reference toolchain. Fonts embedded (CIDFontType/Identity-H), so it renders without Japanese fonts installed. Carries PDF title, author, subject and keywords |
| `mobius-cpt-note.tex` | Source, for the deposit's source archive |
| `mobius-cpt-note.bib` | Bibliography in BibTeX form |
| `README.md` | Build note: both supported toolchains, the three-route Japanese font cascade, the exact Debian packages, the numbering convention, and which files quote the pinned revision |
| `CITATION.cff` | Repository citation metadata. Validates against the official CFF 1.2.0 schema |
| `zenodo-metadata.json` | Deposit metadata in Zenodo's `{"metadata": {...}}` shape |
| `source-snapshot-fad7a6224ae608a56be5f212ece8837d209199bd.tar.gz` | The repository tree at the pinned revision, 125 files, produced by `git archive` |

## What the source snapshot is, and is not

The archive is the repository **at the pinned revision `fad7a62`** — exactly the state whose
formalisation status the note's Sections 7 and 8 describe. Its Lean sources and its
`scripts/print_axioms.lean` are the ones the two counts below refer to.

It is **not** a snapshot of the note. The copy of `docs/note/` inside the archive is the
previous version of the note (the one merged under Issue #67); the current note is the `.pdf`
and `.tex` supplied alongside it in this bundle. The note's revision changed no Lean source, so
the two are consistent: the mathematics the archive contains is the mathematics the current note
reports.

## Release topology

The deposit carries the note together with the pinned source archive. The development
repository is now public at <https://github.com/uda-lab/mobius-cpt> (the owner completed the
visibility change under Issue #76, observed 2026-09-01); the note still assumes no access to
the repository is required — Section 7.1 says that the archive travels with the note and that
the claims of Sections 7 and 8 are to be checked against the archive — and now also names the
public repository URL as an additional avenue. The pinned source archive in this bundle remains
the archival copy independent of the repository's live state.

## Owner decisions (resolved 2026-09-01, Issue #76)

1. **ORCID** — resolved. `0000-0002-6073-1572`, recorded in `zenodo-metadata.json`
   (`creators[0].orcid`, Zenodo's bare form) and `CITATION.cff`
   (`orcid: "https://orcid.org/0000-0002-6073-1572"`).
2. **Affiliation** — resolved. "Faculty of Science and Technology, Nanzan University",
   the official English name Nanzan University uses on its English undergraduate-programs
   page, recorded in the same two places. No department, title or address is added.
3. **Authorship.** Resolved as acknowledgement, not authorship or CFF/Zenodo contributor
   status. 元良直輝氏 (Naoki Genra) provided the mathematical note that was the project's
   starting point; the note now carries a 謝辞 paragraph before the bibliography thanking
   him for that, with no claim of responsibility for the formalisation, this manuscript,
   verification, or conclusions. `CITATION.cff` and `zenodo-metadata.json` continue to
   record Tomoki Uda as sole author/creator.
4. **Repository visibility.** Resolved. The loop's GitHub identity could not perform this
   step itself — it holds `maintain`, not `admin`
   (`gh api repos/uda-lab/mobius-cpt --jq .permissions` → `admin: false`), and changing
   visibility requires admin — so the PR for Issue #76 identified the one remaining manual
   action (**Settings → General → Danger Zone → Change visibility → Public**) and the owner
   completed it. `gh api repos/uda-lab/mobius-cpt --jq .private` now returns `false`; the
   repository is public at <https://github.com/uda-lab/mobius-cpt>. The "not publicly
   accessible" wording in `zenodo-metadata.json`'s description and in this file's "Release
   topology" section above has been updated accordingly.

## Settled without needing the owner

- **Licence**: Apache-2.0, taken from the repository's `LICENSE`. Not invented.
  `zenodo-metadata.json` uses Zenodo's identifier `apache2.0`.
- **Version**: `0.1.0` — unchanged. No deposit was made at `0.1.0`, so this is still the first
  release; bumping would imply a superseded public version that does not exist.
- **Publication date**: 2026-09-01. **Upload type**: publication / preprint,
  `access_right: open`, `language: jpn`.
- **Related identifiers**: the repository at the pinned commit
  `fad7a6224ae608a56be5f212ece8837d209199bd`, the repository root, and both source
  preprints (arXiv:2506.10625, arXiv:2409.08454).
- **No GitHub release was created.** The repository does not use releases and one was not
  introduced.

## Status the deposit describes

Pinned to `fad7a6224ae608a56be5f212ece8837d209199bd` (2026-09-01), at which:

- the **live axiom audit** runs `#print axioms` on **874 declarations** — theorems, definitions
  and instances alike, every name in `scripts/print_axioms.lean` — and each depends only on
  `{propext, Classical.choice, Quot.sound}`;
- a separate **coverage guard** verifies that every file of the development is reachable from
  the aggregate import and that every one of the **815 public theorems** it enumerates appears
  in that audit's list. The two numbers count different things: the 815 theorems are a subset of
  the 874 audited declarations, and the difference is definitions and instances, which are
  pinned too;
- CI run [33431193355](https://github.com/uda-lab/mobius-cpt/actions/runs/33431193355) on
  exactly that commit is `completed/success`.

[T26] Theorem 3.10 (i)(ii)(iii) is proved at that revision, together with the Reeh–Schlieder
property for `I_±` ([CRTT25] Cor. A.3(i) specialised to `I = I_±`), the relative `C^∞(S¹)`
topology on `𝓧`, and the equivalence of [T26] Definition 3.2's endpoint condition with the
real-jet reading. The note is labelled a preliminary research note; publication implies no peer
review.

## Rebuilding the PDF

Reference build, the one that produced the PDF in this bundle:

```sh
cd docs/note && mkdir -p fonts && cd fonts
base=https://github.com/notofonts/noto-cjk/raw/main
curl -LO $base/Serif/OTF/Japanese/NotoSerifCJKjp-Regular.otf
curl -LO $base/Serif/OTF/Japanese/NotoSerifCJKjp-Bold.otf
curl -LO $base/Sans/OTF/Japanese/NotoSansCJKjp-Regular.otf
curl -LO $base/Sans/OTF/Japanese/NotoSansCJKjp-Bold.otf
cd .. && tectonic -X compile mobius-cpt-note.tex
```

On an ordinary TeX Live, with no font download at all, `latexmk -xelatex mobius-cpt-note.tex`
produces the same document: the preamble falls back to the Harano Aji fonts that ship with
TeX Live 2020 and later. `README.md` gives the full font cascade and the exact Debian packages.

All three routes were verified from these sources: 23 pages each, no error, no warning, no
missing character, and no overfull or underfull box.
